import numpy as np
import matplotlib.pyplot as plt


# DATA

d = 17.5  # mm
h = 32    # mm

def rpm_to_gamma(rpm):
    return (np.pi * d / (60 * h)) * np.array(rpm)

# ---- 0.7 g/kg ----
rpm_07_30 = [100, 60, 50, 30]
mu_07_30  = [39, 50, 53, 60]

rpm_07_40 = [100, 60, 50, 30]
mu_07_40  = [36.5, 49, 51.5, 60]

# ---- 0.8 g/kg (NEW) ----
rpm_08_30 = [100, 60, 30]
mu_08_30  = [53, 69, 88]

rpm_08_40 = [100, 60, 30]
mu_08_40  = [48, 64, 84]

# ---- 0.9 g/kg ----
rpm_09_30 = [100, 60, 50, 30]
mu_09_30  = [44, 60, 65, 76]

rpm_09_40 = [100, 60, 50, 30]
mu_09_40  = [40, 50, 53, 60]

# ---- 1.1 g/kg ----
rpm_11_30 = [100, 60, 50, 30]
mu_11_30  = [46.5, 61, 65, 78]

rpm_11_40 = [100, 60, 50, 30]
mu_11_40  = [49.5, 65, 70, 84]



# PLOT


fig, axs = plt.subplots(1, 2, figsize=(14, 5))

colors = {
    '0.7': '#1f77b4',  # bleu
    '0.8': '#ff7f0e',  # orange
    '0.9': '#2ca02c',  # vert
    '1.1': '#d62728'   # rouge
}

datasets_30 = [
    ('0.7', rpm_07_30, mu_07_30),
    ('0.8', rpm_08_30, mu_08_30),
    ('0.9', rpm_09_30, mu_09_30),
    ('1.1', rpm_11_30, mu_11_30),
]

datasets_40 = [
    ('0.7', rpm_07_40, mu_07_40),
    ('0.8', rpm_08_40, mu_08_40),
    ('0.9', rpm_09_40, mu_09_40),
    ('1.1', rpm_11_40, mu_11_40),
]


for label, rpm, mu in datasets_30:
    gd = rpm_to_gamma(rpm)
    axs[0].plot(gd, mu, 'o-', color=colors[label],
                linewidth=2, markersize=6,
                label=rf'$\omega$ = {label} g/kg')


for label, rpm, mu in datasets_40:
    gd = rpm_to_gamma(rpm)
    axs[1].plot(gd, mu, 's-', color=colors[label],
                linewidth=2, markersize=6,
             label=rf'$\omega$ = {label} g/kg')

for ax, temp in zip(axs, ['30°C', '40°C']):
    ax.set_title(temp, fontsize=13)
    ax.set_xlabel(r'$\dot{\gamma}$ (s$^{-1}$)', fontsize=11)
    ax.set_ylabel(r'$\mu$ (cP)', fontsize=11)
    ax.grid(True, linestyle='--', alpha=0.5)
    ax.legend(title="Concentration", fontsize=9)

plt.tight_layout()
plt.show()