import numpy as np
import matplotlib.pyplot as plt
import os
import matplotlib.ticker as ticker

# Style
plt.rcParams.update({
    "font.size": 12,
    "axes.labelsize": 13,
    "legend.fontsize": 11
})

grid_style = {'linestyle': '--', 'linewidth': 0.8, 'alpha': 0.6}


# DATA


# 30°C
mu30 = np.array([39, 50, 53, 60, 48, 60, 90])  # cP
RPM  = np.array([100, 60, 50, 30, 20, 12, 10])

per_cent_down30 = np.array([3.2, 2.5, 2.2, 1.5, 0.8, 0.6, 0.7])
per_cent_up30   = np.array([3.2, 2.5, 2.2, 1.5, 0.8, 0.6, 0.8])

# 40°C
mu_down40 = np.array([36, 48, 50, 60, 48, 50, 80])
mu_up40   = np.array([37, 50, 53, 60, 48, 60, 100])

per_cent_down40 = np.array([3.0, 2.4, 2.1, 1.5, 0.8, 0.5, 0.7])
per_cent_up40   = np.array([3.1, 2.5, 2.2, 1.5, 0.8, 0.6, 0.8])


# MEAN + ERROR


mu40_mean = (mu_down40 + mu_up40) / 2
mu40_err  = (mu_up40 - mu_down40) / 2

per_cent_mean30 = (per_cent_down30 + per_cent_up30) / 2
per_cent_err30  = (per_cent_up30 - per_cent_down30) / 2

per_cent_mean40 = (per_cent_down40 + per_cent_up40) / 2
per_cent_err40  = (per_cent_up40 - per_cent_down40) / 2


# RPM → SHEAR RATE


d = 17.5  # mm
h = 32    # mm

gamma_dot = (np.pi * d / (60 * h)) * RPM  # s^-1


# PLOT VISCOSITY


fig, axs = plt.subplots(1, 2, figsize=(13, 4))

# 30°C
axs[0].plot(gamma_dot, mu30, 'o-', color='darkblue', linewidth=2, label='30°C')
axs[0].set_title('30°C')
axs[0].set_xlabel(r'$\dot{\gamma}$ (s$^{-1}$)')
axs[0].set_ylabel(r'$\mu$ (cP)')
axs[0].grid(**grid_style)
axs[0].legend()

# 40°C
axs[1].errorbar(gamma_dot, mu40_mean, yerr=mu40_err,
                fmt='s-', color='red', linewidth=2, capsize=3, label='40°C')
axs[1].set_title('40°C')
axs[1].set_xlabel(r'$\dot{\gamma}$ (s$^{-1}$)')
axs[1].grid(**grid_style)
axs[1].legend()

plt.tight_layout()
os.makedirs("images", exist_ok=True)
plt.savefig("images/viscosity_vs_shear.png", dpi=300)
plt.show()


# PLOT TORQUE


fig, axs = plt.subplots(1, 2, figsize=(13, 4))

# 30°C
axs[0].errorbar(gamma_dot, per_cent_mean30, yerr=per_cent_err30,
                fmt='o-', color='darkblue', linewidth=2, label='30°C')
axs[0].set_title('30°C')
axs[0].set_xlabel(r'$\dot{\gamma}$ (s$^{-1}$)')
axs[0].set_ylabel('Torque (%)')
axs[0].grid(**grid_style)
axs[0].legend()

# 40°C
axs[1].errorbar(gamma_dot, per_cent_mean40, yerr=per_cent_err40,
                fmt='s-', color='red', linewidth=2, label='40°C')
axs[1].set_title('40°C')
axs[1].set_xlabel(r'$\dot{\gamma}$ (s$^{-1}$)')
axs[1].grid(**grid_style)
axs[1].legend()

plt.tight_layout()
plt.savefig("images/torque_vs_shear.png", dpi=300)
plt.show()


# LOG-LOG FIT


mask = RPM >= 30
gamma_dot_fit = gamma_dot[mask]
mu30_fit      = mu30[mask]
mu40_fit      = mu40_mean[mask]

coeffs30 = np.polyfit(np.log10(gamma_dot_fit), np.log10(mu30_fit), 1)
slope30, intercept30 = coeffs30

coeffs40 = np.polyfit(np.log10(gamma_dot_fit), np.log10(mu40_fit), 1)
slope40, intercept40 = coeffs40

log_gamma_fit = np.linspace(np.log10(min(gamma_dot_fit)), np.log10(max(gamma_dot_fit)), 100)
log_mu_fit30  = intercept30 + slope30 * log_gamma_fit
log_mu_fit40  = intercept40 + slope40 * log_gamma_fit

fig, axs = plt.subplots(1, 2, figsize=(13, 4))

# 30°C
axs[0].scatter(np.log10(gamma_dot_fit), np.log10(mu30_fit), color='darkblue', s=50, label='Data')
axs[0].plot(log_gamma_fit, log_mu_fit30, '--', color='black', label='Fit')
axs[0].set_title('30°C')
axs[0].set_xlabel(r'$\log(\dot{\gamma})$ ')
axs[0].set_ylabel(r'$\log(\mu)$ ')
axs[0].grid(**grid_style)
axs[0].legend()

# 40°C
axs[1].scatter(np.log10(gamma_dot_fit), np.log10(mu40_fit), color='red', s=50, label='Data')
axs[1].plot(log_gamma_fit, log_mu_fit40, '--', color='black', label='Fit')
axs[1].set_title('40°C')
axs[1].set_xlabel(r'$\log(\dot{\gamma})$ ')
axs[1].set_ylabel(r'$\log(\mu)$ ')
axs[1].grid(**grid_style)
axs[1].legend()

plt.tight_layout()
plt.savefig("images/loglog_fit.png", dpi=300)
plt.show()


# RESULTS


n30 = slope30 + 1
k30 = 10**intercept30

n40 = slope40 + 1
k40 = 10**intercept40

print("\n---- RESULTS ----")
print(f"30°C → n = {n30:.3f}, K = {k30 * 0.001:.6f} Pa·s^n")
print(f"40°C → n = {n40:.3f}, K = {k40 * 0.001:.6f} Pa·s^n")



# COMPARISON 30°C vs 40°C (RPM >= 30)


mask_temp = RPM >= 30

gamma_dot_temp = gamma_dot[mask_temp]
mu30_temp = mu30[mask_temp]
mu40_temp = mu40_mean[mask_temp]
mu40_temp_err = mu40_err[mask_temp]

plt.figure(figsize=(7, 5))

plt.plot(gamma_dot_temp, mu30_temp, 'o-', color='darkblue', linewidth=2, label='30°C')
plt.errorbar(gamma_dot_temp, mu40_temp, yerr=mu40_temp_err,
             fmt='s-', color='red', linewidth=2, capsize=3, label='40°C')

plt.xlabel(r'$\dot{\gamma}$ (s$^{-1}$)')
plt.ylabel(r'$\mu$ (cP)')

plt.grid(**grid_style)
plt.legend()

plt.tight_layout()
plt.savefig("images/temperature_effect_viscosity.png", dpi=300)
plt.show()