import numpy as np 
import matplotlib.pyplot as plt 
import os
from CoolProp.CoolProp import PropsSI

plt.rcParams.update({"font.size": 12,"axes.labelsize": 13,"legend.fontsize": 11})
grid_style = {'linestyle': '--', 'linewidth': 0.8, 'alpha': 0.6}


L = np.array([28.9, 28.9, 29, 29, 29, 29.1, 29.3, 29.4, 29.5, 29.6, 29.7, 29.8, 29.9, 30, 30.1, 30.2, 30.3, 30.3, 30.4,
              30.5, 30.6, 30.7, 30.8, 30.9, 31.0, 31.1, 31.2, 31.3, 31.4, 31.5, 31.6])

L_prime = 28.8          #mm
L0 = 5.7                #cm
L = L - L_prime + L0*10

minute = 60 # s

t = np.array([1*minute + 56, 3*minute +20, 4*minute + 12, 6*minute + 6, 8*minute + 0, 9*minute + 30,
               10*minute + 20, 11*minute +10, 12*minute +10, 13*minute + 54, 14*minute + 18, 
              14*minute + 50, 15*minute + 38, 16*minute + 35, 17*minute + 56, 18*minute + 50, 19*minute + 39,
             21*minute + 8, 21*minute + 46, 22*minute + 35, 23*minute + 27, 24*minute + 44, 
              25*minute + 51, 26*minute + 40, 27*minute + 23, 28*minute + 14, 28*minute + 42,
              29*minute + 18, 30*minute + 6, 30*minute + 46, 31*minute + 16])

L = L * 1e-3 #m 
L2 = L**2

# Régression
a, b = np.polyfit(t, L2, 1) #Units = m^2 = [a]*t + [b] => [b] = m^2, [a] = m^2/s




print(f"Linear regression result : \n a = {a:.3e} m^2/s,\n b = {b:.3e} m^2.")

t_fit = np.linspace(min(t), max(t), 200)

plt.figure(figsize=(7,5))
plt.scatter(t, L2, s=40, edgecolors='black', label="Experimental data")
plt.plot(t_fit, a*t_fit + b, linewidth=2,  label=f"\n$L^2 = ({a:.2e})t + ({b:.2e})$")
plt.xlabel("Time (s)")
plt.ylabel(r"$L^2$ (m$^2$)")
plt.grid(**grid_style)
plt.legend(frameon=True, loc="upper left")
plt.tight_layout()
os.makedirs("images", exist_ok=True)
plt.savefig("images/L2_vs_time.png", dpi=300, bbox_inches='tight')



rho_l = 790             #kg/m3
Ml = 58.08              #kg/kmol 
Cl = rho_l/Ml * 1000    #mol/m3


T = 37 + 273.15         #K
P = 101325              #Pa
R = 8.314               #J/mol-K

C = P/R/T
Aa = 4.42448
Bb = 1312.253
Cc = -32.445

#p_A0 = PropsSI("P", "T", T, "Q", 0, "Acetone")
p_A0 = 10**(Aa - Bb/(T+Cc)) # Bar
p_A0 = p_A0*10**5


Ca0 = p_A0/R/T
D_AB = (a/2) * (Cl/C) * (1/ np.log(C/ (C - Ca0)))




def D_AB_th(t) : 
    vb = 3*14.8 + 6*3.7 + 1*7.4
    sigma_A =  1.18 * vb**(1/3)
    sigma_B = 3.617 #Å
    sigma_AB = (sigma_A + sigma_B)/2
    k_b = 1.32054e-23
    e_B = 97 * k_b
    Tc = 508.15
    e_A = Tc* k_b /1.3
    e_AB = np.sqrt(e_A * e_B)
    c = k_b * t / e_AB
    o_AB = 1.167 - (1.59 - 1.55)  / (1.60 - 1.55 )* (1.167 - 1.182)
    Mb = 58.08
    Ma = 28.97
    return (1.858e-3 * (t**1.5) )* ((1/Ma + 1/Mb)**(1/2) )/ (1 * sigma_AB**2 * o_AB)

D_AB_th_group1= D_AB_th(37+273.15)
D_AB_th_group2= D_AB_th(38+273.15)
D_AB_th_group3= D_AB_th(41+273.15)
D_AB_th_group4= D_AB_th(45+273.15)


'''
vb = 3*14.8 + 6*3.7 + 1*7.4
sigma_A =  1.18 * vb**(1/3)
sigma_B = 3.617 #Å
sigma_AB = (sigma_A + sigma_B)/2
k_b = 8.314/ 6.022e23
e_B = 97 * k_b
Tc = PropsSI("Tcrit", "Acetone")
e_A = Tc* k_b /1.3
e_AB = np.sqrt(e_A * e_B)
c = k_b * T / e_AB
o_AB = 1.167 - (1.59 - 1.55)  / (1.60 - 1.55 )* (1.167 - 1.182)
Mb = 58.08
Ma = 28.97
'''
#print(f"p_A0 = {p_A0:.2f} Pa")
#print(f"C : {C:.2f} mol/m3")
#print(f"Cl: {Cl:.2f} mol/m3")
#print(f"Ca0 : {Ca0:.2f} mol/m3")
#print(f"D_AB = {D_AB:.2e} m^2/s")
#print(f"Van der Waals volume of acetone : V_vdW = {vb:.2f} cm^3/mol")
#print(f"sigma_A = {sigma_A:.2f} Angstrom")
#print(f"sigma_B = {sigma_B:.2f} Angstrom")
#print(f"sigma_AB = {sigma_AB:.2f} Angstrom")
#print(f" e_B = {e_B:.2e} J")
#print(f" Tc = {Tc:.2f} K")
#print(f" e_A = {e_A:.2e} J")
#print(f"e_AB = {e_AB:.2e} J")
#print(f"Dimensionless parameter c = {c:.2f}")
#print(f"o_AB = {o_AB:.3f} Angstrom")
print(f"D_AB_th_group1 = {D_AB_th_group1:.3e} cm^2/s")
print(f"D_AB_th_group4 = {D_AB_th_group2:.3e} cm^2/s")
print(f"D_AB_th_group2 = {D_AB_th_group3:.3e} cm^2/s")
print(f"D_AB_th_group3 = {D_AB_th_group4:.3e} cm^2/s")


