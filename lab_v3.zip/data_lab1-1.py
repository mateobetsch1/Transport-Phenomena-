import numpy as np 
import matplotlib.pyplot as plt 
import os


plt.rcParams.update({"font.size": 12,"axes.labelsize": 13,"legend.fontsize": 11})
grid_style = {'linestyle': '--', 'linewidth': 0.8, 'alpha': 0.6}
minute = 60 #s

#groupe 2 
t_groupe2 = np.array([0*minute, 
2*minute, 
4*minute, 
6*minute, 
8*minute, 
10*minute, 
12*minute, 
14*minute, 
16*minute, 
18*minute, 
20*minute, 
22*minute, 
24*minute, 
26*minute, 
28*minute, 
30*minute,
])

L2_0prime = 27.7 #mm
L20 = 56 #mm

L2_squarred = np.array([
767.29,
778.41,
778.41,
784,
846.81,
870.25,
906.01,
948.64,
1011.24,
998.56,
1043.29,
1049.76,
1069.29,
1075.84,
1082.41,
1082.41
])

L2_prime = np.array([
27.7,
27.9,
27.9,
28,
29.1,
29.5,
30.1,
30.8,
31.8,
31.6,
32.3,
32.4,
32.7,
32.8,
32.9,
32.9
])
L2 = L20 + (L2_prime - L2_0prime) #mm
L2_squared = (L2/1000)**2 #m^2

#groupe 3 
t_groupe3 = np.array([
0*minute,
2*minute, 
4*minute, 
6*minute, 
8*minute, 
10*minute, 
12*minute, 
14*minute, 
16*minute, 
18*minute, 
20*minute, 
22*minute, 
24*minute, 
26*minute, 
28*minute, 
30*minute, 
])


L3 = np.array([
23.4,
23.4,
23.6,
23.7,
23.9,
24,
24,
24.1,
24.2,
24.4,
24.5,
24.6,
24.6,
24.7,
24.9,
24.9
])

L_0_3 = 51 #mm
L_prime3 = 23.4 #mm

L3 = L_0_3 + (L3 - L_prime3) #mm
L3_squared = (L3/1000)**2 #m^2



#groupe 4

t_groupe4 = np.array([
120.89,
240.82,
360.59,
480.89,
596.72,
717.07,
837,
956.64,
1076.97,
1196.97,
1317.46,
1441.82,
1562.15,
1683.2,
1799.69
])

L_prime4 = np.array([
27.6,
27.6,
27.7,
27.8,
27.8,
27.9,
27.9,
28,
28.1,
28.1,
28.2,
28.2,
28.3,
28.4,
28.4
])  

L0_4 = 56 #mm
L_prime_04 = 27.6 #mm

L4 = L0_4 + (L_prime4 - L_prime_04) #mm
L4_squared = (L4/1000)**2 #m^2




L1= np.array([28.9, 28.9, 29, 29, 29, 29.1, 29.3, 29.4, 29.5, 29.6, 29.7, 29.8, 29.9, 30, 30.1, 30.2, 30.3, 30.3, 30.4,
              30.5, 30.6, 30.7, 30.8, 30.9, 31.0, 31.1, 31.2, 31.3, 31.4, 31.5, 31.6])

L1_prime = 28.8          #mm
L10 = 5.7                #cm
L1 = L1 - L1_prime + L10*10

minute = 60 # s

t_groupe1 = np.array([1*minute + 56, 3*minute +20, 4*minute + 12, 6*minute + 6, 8*minute + 0, 9*minute + 30,
               10*minute + 20, 11*minute +10, 12*minute +10, 13*minute + 54, 14*minute + 18, 
              14*minute + 50, 15*minute + 38, 16*minute + 35, 17*minute + 56, 18*minute + 50, 19*minute + 39,
             21*minute + 8, 21*minute + 46, 22*minute + 35, 23*minute + 27, 24*minute + 44, 
              25*minute + 51, 26*minute + 40, 27*minute + 23, 28*minute + 14, 28*minute + 42,
              29*minute + 18, 30*minute + 6, 30*minute + 46, 31*minute + 16])

L_groupe1 = L1 * 1e-3 #m 
L1_squared = L_groupe1**2

from scipy.stats import linregress

def calcul_regression(t, y):
    slope, intercept, r_value, p_value, std_err = linregress(t, y)
    return slope, intercept, r_value**2


groupes = {
    "Group 1": (t_groupe1, L1_squared, 37), 
    "Group 4": (t_groupe4, L4_squared, 38), 
    "Group 2": (t_groupe2, L2_squared, 41), 
    "Group 3": (t_groupe3, L3_squared, 45), 
}






def calc_DAB(t, y, Temp_C):
    slope, intercept, r_value, p_value, std_err = linregress(t, y)

    rho_l = 790          # kg/m3
    Ml = 58.08           # kg/kmol
    Cl = rho_l / Ml * 1000   # mol/m3

    T = Temp_C + 273.15  # K
    P = 101325           # Pa
    R = 8.314            # J/mol/K

    C = P / (R * T)

    Aa = 4.42448
    Bb = 1312.253
    Cc = -32.445

    p_A0 = 10**(Aa - Bb/(T + Cc))   # bar
    p_A0 = p_A0 * 1e5               # Pa

    Ca0 = p_A0 / (R * T)

    D_AB = (slope/2) * (Cl / C) * (1 / np.log(C / (C - Ca0)))

    return D_AB, slope, intercept, r_value**2


D_AB_exp = []
plt.figure(figsize=(10, 6))

for nom, (t, y, Temp) in groupes.items():
    slope, intercept, r2 = calcul_regression(t, y)
    D_AB, slope, intercept, r2 = calc_DAB(t, y, Temp)

    print(f"\n===== {nom} =====")
    print(f"Pente a = {slope:.3e} m2/s")
    print(f"Ordonnée b = {intercept:.3e} m2")
    print(f"R^2 = {r2:.5f}")
    print(f"D_AB = {D_AB:.3e} m2/s")
    D_AB_exp.append(D_AB)
    plt.scatter(t, y, s=35, edgecolors='black', label=f"{nom} data")

    t_fit = np.linspace(np.min(t), np.max(t), 200)
    y_fit = slope * t_fit + intercept
    plt.plot(t_fit, y_fit, linewidth=2, label=f"{nom} fit ($T={Temp} C$)")

plt.xlabel("Time (s)")
plt.ylabel(r"$L^2$ (m$^2$)")
plt.title(r"Comparison of $L^2$ evolution for the different groups")
plt.grid(**grid_style)
plt.legend()
plt.tight_layout()

os.makedirs("images", exist_ok=True)
plt.savefig("images/comparaison_groupes.png", dpi=300, bbox_inches='tight')
plt.show()


D_AB_exp = np.array(D_AB_exp) * 1e4   

D_AB_th = np.array([
    1.075e-01,   # Group 1
    1.101e-01,   # Group 2
    1.128e-01,   # Group 3
    1.082e-01,   # Group 4
])

labels = ["Group 1", "Group 4", "Group 2", "Group 3"]

x = np.arange(len(labels))
width = 0.36

plt.figure(figsize=(9,5))

plt.bar(x - width/2, D_AB_exp, width, label="Experimental", edgecolor='black')

plt.bar(x + width/2, D_AB_th, width, label="Theoretical", edgecolor='black')

for i in range(len(labels)):
    plt.text(x[i]-width/2, D_AB_exp[i] + 0.002, f"{D_AB_exp[i]:.3f}", ha='center', fontsize=9)

    plt.text(x[i]+width/2, D_AB_th[i] + 0.002, f"{D_AB_th[i]:.3f}", ha='center', fontsize=9)

plt.xticks(x, labels)
plt.ylabel(r"$D_{AB}$ (cm$^2$/s)")
plt.title(r"Comparison of theoretical and experimental $D_{AB}$")
plt.grid(axis='y', **grid_style)
plt.legend()
plt.tight_layout()

plt.savefig("images/DAB_comparison.png", dpi=300, bbox_inches='tight')
plt.show()

error = np.abs(D_AB_exp - D_AB_th) / D_AB_th
print(f"Error = {error*100} %")


# Résumé complet de tous les groupes 
print("\n" + "="*60)
print("RÉSUMÉ COMPLET")
print("="*60)

for i, (nom, (t, y, Temp)) in enumerate(groupes.items()):
    slope, intercept, r_value, p_value, std_err = linregress(t, y)
    r2 = r_value**2
    D_m2 = D_AB_exp[i] / 1e4  # cm²/s → m²/s

    slope_cm2 = slope * 1e4       # m²/s → cm²/s
    intercept_cm2 = intercept * 1e4  # m² → cm²

    print(f"\n----- {nom} (T = {Temp} °C) -----")
    print(f"  a (pente)        = {slope_cm2:.4e} cm²/s")
    print(f"  b (ordonnée)     = {intercept_cm2:.4e} cm²")
    print(f"  R                = {r_value:.5f}")
    print(f"  R²               = {r2:.5f}")
    print(f"  D_AB_exp         = {D_m2:.4e} m²/s")
    print(f"  D_AB_exp         = {D_AB_exp[i]:.4f} cm²/s")
    print(f"  D_AB_th          = {D_AB_th[i]:.4f} cm²/s")
    print(f"  Erreur relative  = {abs(D_AB_exp[i] - D_AB_th[i])/D_AB_th[i]*100:.2f} %")
    
    
# Graphique D_AB vs Température 
temps_groupes = [37, 38, 41, 45]  # °C, ordre: Group1, Group4, Group2, Group3

plt.figure(figsize=(9, 6))

plt.scatter(temps_groupes, D_AB_exp, color='steelblue', s=80, zorder=5, 
            edgecolors='black', label='Experimental')
plt.scatter(temps_groupes, D_AB_th, color='crimson', s=80, zorder=5, 
            edgecolors='black', marker='s', label='Theoretical')


for i in range(len(temps_groupes)):
    plt.plot([temps_groupes[i], temps_groupes[i]], 
             [D_AB_exp[i], D_AB_th[i]], 
             'gray', linestyle='--', linewidth=1)


for i, nom in enumerate(labels):
    plt.annotate(nom, (temps_groupes[i], D_AB_exp[i]),
                 textcoords="offset points", xytext=(6, 5), fontsize=9, color='steelblue')
    plt.annotate(nom, (temps_groupes[i], D_AB_th[i]),
                 textcoords="offset points", xytext=(6, -12), fontsize=9, color='crimson')

plt.xlabel("Temperature (°C)")
plt.ylabel(r"$D_{AB}$ (cm²/s)")
plt.legend()
plt.grid(**grid_style)
plt.tight_layout()
plt.savefig("images/DAB_vs_temp.png", dpi=300, bbox_inches='tight')
plt.show()
    
# Graphique D_AB vs Température
temps_groupes = [37, 38, 41, 45]  # °C, ordre: Group1, Group4, Group2, Group3

plt.figure(figsize=(9, 6))

plt.scatter(temps_groupes, D_AB_exp, color='steelblue', s=80, zorder=5, 
            edgecolors='black', label='Experimental')
plt.scatter(temps_groupes, D_AB_th, color='crimson', s=80, zorder=5, 
            edgecolors='black', marker='s', label='Theoretical')

# Relier les points exp et th pour chaque groupe
for i in range(len(temps_groupes)):
    plt.plot([temps_groupes[i], temps_groupes[i]], 
             [D_AB_exp[i], D_AB_th[i]], 
             'gray', linestyle='--', linewidth=1)

# Annotations
for i, nom in enumerate(labels):
    plt.annotate(nom, (temps_groupes[i], D_AB_exp[i]),
                 textcoords="offset points", xytext=(6, 5), fontsize=9, color='steelblue')
    plt.annotate(nom, (temps_groupes[i], D_AB_th[i]),
                 textcoords="offset points", xytext=(6, -12), fontsize=9, color='crimson')

plt.xlabel("Temperature (°C)")
plt.ylabel(r"$D_{AB}$ (cm²/s)")
plt.title(r"$D_{AB}$ experimental vs theoretical as a function of temperature")
plt.legend()
plt.grid(**grid_style)
plt.tight_layout()
plt.savefig("images/DAB_vs_temp.png", dpi=300, bbox_inches='tight')
plt.show()

# Même graphique mais en cm²
plt.figure(figsize=(10, 6))

for nom, (t, y, Temp) in groupes.items():
    slope, intercept, r2 = calcul_regression(t, y)
    y_cm2 = y * 1e4  # m² → cm²
    slope_cm2 = slope * 1e4
    intercept_cm2 = intercept * 1e4

    plt.scatter(t, y_cm2, s=35, edgecolors='black', label=f"{nom} data")

    t_fit = np.linspace(np.min(t), np.max(t), 200)
    y_fit = slope_cm2 * t_fit + intercept_cm2
    plt.plot(t_fit, y_fit, linewidth=2, label=f"{nom} fit ($T={Temp} C$)")

plt.xlabel("Time (s)")
plt.ylabel(r"$L^2$ (cm$^2$)")
plt.grid(**grid_style)
plt.legend()
plt.tight_layout()
plt.savefig("images/comparaison_groupes_cm2.png", dpi=300, bbox_inches='tight')
plt.show()


#  Graphique L² vs temps - Groupe 1 seulement 
t_g1, y_g1, Temp_g1 = groupes["Group 1"]


N = 5  
t_g1_fit = t_g1[N:]
y_g1_fit = y_g1[N:]

slope_g1, intercept_g1, r2_g1 = calcul_regression(t_g1_fit, y_g1_fit)

y_g1_cm2 = y_g1 * 1e4
slope_g1_cm2 = slope_g1 * 1e4
intercept_g1_cm2 = intercept_g1 * 1e4

t_fit = np.linspace(np.min(t_g1_fit), np.max(t_g1_fit), 200)
y_fit = slope_g1_cm2 * t_fit + intercept_g1_cm2

plt.figure(figsize=(9, 6))
# Tous les points en gris
plt.scatter(t_g1[:N], y_g1[:N]*1e4, s=50, edgecolors='black', color='gray', 
            label='Excluded data', zorder=5)
# Points utilisés pour le fit en bleu
plt.scatter(t_g1_fit, y_g1_fit*1e4, s=50, edgecolors='black', color='steelblue', 
            label='Group 1 data', zorder=5)
plt.plot(t_fit, y_fit, color='steelblue', linewidth=2,
         label=f'$L^2 = {slope_g1_cm2:.6f} \\cdot t + {intercept_g1_cm2:.4f}$\n$R^2={r2_g1:.4f}$')

plt.xlabel("Time (s)")
plt.ylabel(r"$L^2$ (cm$^2$)")
plt.legend()
plt.grid(**grid_style)
plt.tight_layout()
plt.savefig("images/L2_groupe1.png", dpi=300, bbox_inches='tight')
plt.show()