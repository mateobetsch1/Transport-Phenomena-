import numpy as np 
import matplotlib.pyplot as plt 
from matplotlib.ticker import ScalarFormatter
import os

plt.rcParams.update({"font.size": 12,"axes.labelsize": 13,"legend.fontsize": 11})
grid_style = {'linestyle': '--', 'linewidth': 0.8, 'alpha': 0.6}


minute = 60 #s

t =            np.array([0,      3.11,    3.4,    3.7,   4.08,    4.8,   4.93,   5.22,   5.84,   6.48,    7.2,  7.6,    9.3,11.84, 13.90, 17.11, 23.12, 
                        1*minute + 7, 1*minute + 34, 2*minute + 1, 2*minute + 37, 3*minute + 10, 5*minute + 35, 7*minute + 40, 9*minute + 40, 10*minute + 37,
                        11*minute + 35, 12*minute + 35, 17*minute + 12, 18*minute + 40, 22*minute + 19, 23*minute + 51, 24*minute + 24, 25*minute + 30,
                        26*minute + 4, 27*minute + 30, 28*minute + 15, 28*minute + 50,  29*minute + 53 ,30*minute + 34]) #s

conductivity = np.array([0.5e-5, 1e-5, 2.3e-5, 3.6e-5, 3.9e-5, 4.2e-5, 4.5e-5, 4.0e-5, 5.5e-5, 5.9e-5, 6.5e-5, 7e-5, 7.4e-5, 8e-5, 8.2e-5, 1e-4, 1.1e-4,
                        1.3e-4, 1.4e-4, 1.5e-4, 1.6e-4, 1.7e-4, 1.8e-4, 1.9e-4, 2e-4, 2.1e-4, 2.2e-4, 2.4e-4, 2.7e-4, 2.8e-4, 2.9e-4, 3e-4, 
                        3.1e-4, 3.2e-4, 3.3e-4, 3.5e-4, 3.6e-4, 3.7e-4, 3.8e-4, 3.9e-4]) 



fig, ax = plt.subplots(figsize=(7, 4.5))

ax.plot(t/60, conductivity,marker='o',markersize=4,linewidth=1.8,color='darkblue',label='Experimental data')

ax.set_xlabel('Time (min)')
ax.set_ylabel('Conductivity')
ax.grid(**grid_style)
ax.legend(frameon=True, loc='upper left')
formatter = ScalarFormatter(useMathText=True)
formatter.set_scientific(True)
formatter.set_powerlimits((0, 0))
ax.yaxis.set_major_formatter(formatter)


plt.tight_layout()

os.makedirs("images", exist_ok=True)
plt.savefig("images/conductivity_vs_time.png", dpi=300, bbox_inches='tight')
