import numpy as np 
import matplotlib.pyplot as plt 
import os
from CoolProp.CoolProp import PropsSI

plt.rcParams.update({"font.size": 12,"axes.labelsize": 13,"legend.fontsize": 11})
grid_style = {'linestyle': '--', 'linewidth': 0.8, 'alpha': 0.6}
minute = 60 #s

#groupe 2 
t_groupe2 = np.array([0*minute, 
2*minute, 
4*minute, 
6*minute, 
8*minute, 
10*minute, 
12*minute, 
14*minute, 
16*minute, 
18*minute, 
20*minute, 
22*minute, 
24*minute, 
26*minute, 
28*minute, 
30*minute,
])

L2_0prime = 27.7 #mm
L20 = 48 #mm

L2_squarred = np.array([
767.29,
778.41,
778.41,
784,
846.81,
870.25,
906.01,
948.64,
1011.24,
998.56,
1043.29,
1049.76,
1069.29,
1075.84,
1082.41,
1082.41
])

L2_prime = np.array([
27.7,
27.9,
27.9,
28,
29.1,
29.5,
30.1,
30.8,
31.8,
31.6,
32.3,
32.4,
32.7,
32.8,
32.9,
32.9
])
L2 = L20 + (L2_prime - L2_0prime) #mm
L2_squared = (L2/1000)**2 #m^2

#groupe 3 
t_groupe3 = np.array([
0*minute,
2*minute, 
4*minute, 
6*minute, 
8*minute, 
10*minute, 
12*minute, 
14*minute, 
16*minute, 
18*minute, 
20*minute, 
22*minute, 
24*minute, 
26*minute, 
28*minute, 
30*minute, 
])


L3 = np.array([
23.4,
23.4,
23.6,
23.7,
23.9,
24,
24,
24.1,
24.2,
24.4,
24.5,
24.6,
24.6,
24.7,
24.9,
24.9
])

L_0_3 = 53 #mm
L_prime3 = 23.4 #mm

L3 = L_0_3 + (L3 - L_prime3) #mm
L3_squared = (L3/1000)**2 #m^2



#groupe 4

t_groupe4 = np.array([
120.89,
240.82,
360.59,
480.89,
596.72,
717.07,
837,
956.64,
1076.97,
1196.97,
1317.46,
1441.82,
1562.15,
1683.2,
1799.69
])

L_prime4 = np.array([
27.6,
27.6,
27.7,
27.8,
27.8,
27.9,
27.9,
28,
28.1,
28.1,
28.2,
28.2,
28.3,
28.4,
28.4
])  

L0_4 = 56 #mm
L_prime_04 = 27.6 #mm

L4 = L0_4 + (L_prime4 - L_prime_04) #mm
L4_squared = (L4/1000)**2 #m^2




L1= np.array([28.9, 28.9, 29, 29, 29, 29.1, 29.3, 29.4, 29.5, 29.6, 29.7, 29.8, 29.9, 30, 30.1, 30.2, 30.3, 30.3, 30.4,
              30.5, 30.6, 30.7, 30.8, 30.9, 31.0, 31.1, 31.2, 31.3, 31.4, 31.5, 31.6])

L1_prime = 28.8          #mm
L10 = 5.7                #cm
L1 = L1 - L1_prime + L10*10

minute = 60 # s

t_groupe1 = np.array([1*minute + 56, 3*minute +20, 4*minute + 12, 6*minute + 6, 8*minute + 0, 9*minute + 30,
               10*minute + 20, 11*minute +10, 12*minute +10, 13*minute + 54, 14*minute + 18, 
              14*minute + 50, 15*minute + 38, 16*minute + 35, 17*minute + 56, 18*minute + 50, 19*minute + 39,
             21*minute + 8, 21*minute + 46, 22*minute + 35, 23*minute + 27, 24*minute + 44, 
              25*minute + 51, 26*minute + 40, 27*minute + 23, 28*minute + 14, 28*minute + 42,
              29*minute + 18, 30*minute + 6, 30*minute + 46, 31*minute + 16])

L_groupe1 = L1 * 1e-3 #m 
L1_squared = L_groupe1**2

from scipy.stats import linregress

def calcul_regression(t, y):
    slope, intercept, r_value, p_value, std_err = linregress(t, y)
    return slope, intercept, r_value**2

# =========================
# Données regroupées
# =========================
groupes = {
    "Group 1": (t_groupe1, L1_squared, 37), 
    "Group 4": (t_groupe4, L4_squared, 38), 
    "Group 2": (t_groupe2, L2_squared, 41), 
    "Group 3": (t_groupe3, L3_squared, 45), 
}


# =========================
# Plot unique
# =========================
plt.figure(figsize=(10, 6))

for nom, (t, y, Temp) in groupes.items():
    slope, intercept, r2 = calcul_regression(t, y)
    
    print(f"\n===== {nom} =====")
    print(f"Pente a = {slope:.3e} m²/s")
    print(f"Ordonnée b = {intercept:.3e} m²")
    print(f"R² = {r2:.5f}")
    
    # points expérimentaux
    plt.scatter(t, y, s=35, edgecolors='black', label=f"{nom} data")
    
    # droite de régression
    t_fit = np.linspace(np.min(t), np.max(t), 200)
    y_fit = slope * t_fit + intercept
    plt.plot(t_fit, y_fit, linewidth=2,
             label=f"{nom} fit ($T={Temp}C$)")

plt.xlabel("Time (s)")
plt.ylabel(r"$L^2$ (m$^2$)")
plt.title(r"Comparison of $L^2$ evolution for the different groups")
plt.grid(**grid_style)
plt.legend()
plt.tight_layout()

os.makedirs("images", exist_ok=True)
plt.savefig("images/comparaison_groupes.png", dpi=300, bbox_inches='tight')
plt.show()