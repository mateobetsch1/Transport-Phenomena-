import numpy as np 
import matplotlib.pyplot as plt 
import os

plt.rcParams.update({"font.size": 12,"axes.labelsize": 13,"legend.fontsize": 11})
grid_style = {'linestyle': '--', 'linewidth': 0.8, 'alpha': 0.6}

#Temperature = 30 C
mu30 =            np.array([39,  50,  53,  60,  48,  60,  90  ]) #cP
RPM   =           np.array([100, 60,  50,  30,  20,  12,  10  ]) #RPM
per_cent_down30 = np.array([3.2, 2.5, 2.2, 1.5, 0.8, 0.6, 0.7 ]) #%
per_cent_up30 =   np.array([3.2, 2.5, 2.2, 1.5, 0.8, 0.6, 0.8 ]) #%

#Temperature = 40 C
mu_down40 =       np.array([36,  48,  50,   60,  48,  50, 80  ]) #cP
mu_up40 =         np.array([37,  50,  53,   60,  48,  60, 100 ]) #cP
RPM   =           np.array([100, 60,  50,   30,  20,  12, 10  ]) #RPM
per_cent_down40 = np.array([3.0, 2.4, 2.1, 1.5, 0.8, 0.5, 0.7 ]) #%
per_cent_up40 =   np.array([3.1, 2.5, 2.2, 1.5, 0.8, 0.6, 0.8 ]) #%



mu40_mean = (mu_down40 + mu_up40) / 2
mu40_err  = (mu_up40 - mu_down40) / 2

per_cent_mean30 = (per_cent_down30 + per_cent_up30) / 2
per_cent_err30  = (per_cent_up30 - per_cent_down30) / 2

per_cent_mean40 = (per_cent_down40 + per_cent_up40) / 2
per_cent_err40  = (per_cent_up40 - per_cent_down40) / 2


fig, axs = plt.subplots(1, 2, figsize=(13,4))
#Temperature = 30 C
axs[0].plot(RPM, mu30, 'o-', linewidth=2, color = 'darkblue', label = "Experimental data at 30°C")
axs[0].set_title('30°C')
axs[0].set_xlabel('RPM')
axs[0].set_ylabel('Viscosity (cP)')
axs[0].set_xticks(np.arange(0, 110, 10))
axs[0].grid(**grid_style)
axs[0].legend(frameon=True, loc="upper right")

#Temperature = 40 C
axs[1].errorbar(RPM, mu40_mean, yerr=mu40_err, fmt='s-', linewidth=2, capsize=3, elinewidth=1.3, alpha=  .9 , color = 'red', label = "Eperimental data at 40°C with error bars")
axs[1].set_xticks(np.arange(0, 110, 10))
axs[1].set_title('40°C')
axs[1].set_xlabel('RPM')
axs[1].grid(**grid_style)
axs[1].legend(frameon=True, loc="upper right")


os.makedirs("images", exist_ok=True)
plt.savefig("images/viscosity.png", dpi=300, bbox_inches='tight')
plt.tight_layout()



fig, axs = plt.subplots(1, 2, figsize=(13, 4))

# 30°C
axs[0].errorbar(RPM, per_cent_mean30, yerr=per_cent_err30, fmt='o-', linewidth=2, capsize=3, elinewidth=1.0, alpha=0.9,color='darkblue', label='Experimental data at 30°C')
axs[0].set_title('30°C')
axs[0].set_xlabel('RPM')
axs[0].set_ylabel('Torque (% of full scale)')
axs[0].set_xticks(np.arange(0, 110, 10))
axs[0].grid(**grid_style)
axs[0].legend(frameon=True, loc="upper left")

# 40°C
axs[1].errorbar(RPM, per_cent_mean40, yerr=per_cent_err40, fmt='s-', linewidth=2, capsize=3, elinewidth=1.0, alpha=0.9, color='red', label='Experimental data at 40°C')
axs[1].set_title('40°C')
axs[1].set_xlabel('RPM')
axs[1].set_xticks(np.arange(0, 110, 10))
axs[1].grid(**grid_style)
axs[1].legend(frameon=True, loc="upper left")

plt.tight_layout()
os.makedirs("images", exist_ok=True)
plt.savefig("images/torque_percentage.png", dpi=300, bbox_inches='tight')
