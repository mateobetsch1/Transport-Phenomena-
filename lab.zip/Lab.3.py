import numpy as np
import matplotlib.pyplot as plt
import openpyxl
from scipy.interpolate import make_interp_spline

# =========================
# 1) FONCTIONS
# =========================
def read_group_from_columns(ws, col_t, col_k, min_row=4):
    t_vals = []
    k_vals = []

    for row in ws.iter_rows(min_row=min_row, values_only=True):
        t_val = row[col_t]
        k_val = row[col_k]

        if t_val is None or k_val is None:
            continue

        try:
            t_vals.append(float(t_val))
            k_vals.append(float(k_val))
        except (ValueError, TypeError):
            continue

    return np.array(t_vals, dtype=float), np.array(k_vals, dtype=float)


def ensure_seconds(t):
    """
    Si max(t) < 100, on suppose que le temps est en minutes.
    Sinon, on suppose qu'il est déjà en secondes.
    """
    if len(t) == 0:
        return t

    if np.max(t) < 100:
        return t * 60.0
    else:
        return t


def linear_fit_all(t, k):
    a, b = np.polyfit(t, k, 1)
    fit = a * t + b

    ss_res = np.sum((k - fit) ** 2)
    ss_tot = np.sum((k - np.mean(k)) ** 2)
    r2 = 1 - ss_res / ss_tot if ss_tot != 0 else 1.0

    return a, b, fit, r2


def linear_fit_after_200s(t, k):
    mask = t > 200
    t_sel = t[mask]
    k_sel = k[mask]

    if len(t_sel) < 2:
        return None

    a, b = np.polyfit(t_sel, k_sel, 1)
    fit = a * t_sel + b

    ss_res = np.sum((k_sel - fit) ** 2)
    ss_tot = np.sum((k_sel - np.mean(k_sel)) ** 2)
    r2 = 1 - ss_res / ss_tot if ss_tot != 0 else 1.0

    return t_sel, k_sel, a, b, fit, r2


# =========================
# 2) LECTURE DU FICHIER EXCEL
# =========================
filepath = "Data_Gr1-4.xlsx"
wb = openpyxl.load_workbook(filepath, data_only=True)
ws = wb["Liquid phase diffusion"]

# Colonnes :
# Group 1 : B, C  -> indices 1, 2
# Group 2 : L, M  -> indices 11, 12
# Group 3 : R, S  -> indices 17, 18
# Group 4 : X, Y  -> indices 23, 24  (comme dans ton script)

t_g1, k_g1 = read_group_from_columns(ws, 1, 2, min_row=5)
t_g2, k_g2 = read_group_from_columns(ws, 11, 12, min_row=4)
t_g3, k_g3 = read_group_from_columns(ws, 17, 18, min_row=4)
t_g4, k_g4 = read_group_from_columns(ws, 23, 24, min_row=4)

# Conversion éventuelle en secondes
t_g1 = ensure_seconds(t_g1)
t_g2 = ensure_seconds(t_g2)
t_g3 = ensure_seconds(t_g3)
t_g4 = ensure_seconds(t_g4)

groups = {
    "Group 1": (t_g1, k_g1),
    "Group 2": (t_g2, k_g2),
    "Group 3": (t_g3, k_g3),
    "Group 4": (t_g4, k_g4),
}

# =========================
# 3) VÉRIFICATION CONSOLE
# =========================
for name, (t, k) in groups.items():
    print(f"{name}:")
    print(f"  Number of points = {len(t)}")
    print(f"  Min time = {np.min(t) if len(t) else 'empty'} s")
    print(f"  Max time = {np.max(t) if len(t) else 'empty'} s\n")

# =========================
# 4) GRAPHE 1 : GROUPE 1 - TOUS LES POINTS
# =========================
a_all, b_all, fit_all, r2_all = linear_fit_all(t_g1, k_g1)

plt.figure(figsize=(8, 5))
plt.plot(t_g1, k_g1, 'o', label='experimental data')
plt.plot(t_g1, fit_all, 'r-', label='Linear fit (all data)')

plt.xlabel('Time (s)')
plt.ylabel('Conductivity (S/m)')
plt.title('Evolution of conductivity with time')
plt.grid(True, linestyle='--', alpha=0.6)
plt.legend()

plt.text(
    0.60, 0.20,
    f'y = {a_all:.2e}x + {b_all:.2e}\n$R^2$ = {r2_all:.4f}',
    transform=plt.gca().transAxes,
    bbox=dict(facecolor='white', alpha=0.7)
)

plt.tight_layout()
plt.show()

print("=== Group 1: regression on all data ===")
print(f"Slope = {a_all:.6e} S/m/s")
print(f"Intercept = {b_all:.6e}")
print(f"R² = {r2_all:.4f}\n")

# =========================
# 5) GRAPHE 2 : GROUPE 1 - APRÈS 200 s
# =========================
result_g1_200 = linear_fit_after_200s(t_g1, k_g1)

if result_g1_200 is not None:
    t_sel, k_sel, a_200, b_200, fit_200, r2_200 = result_g1_200

    mask = t_g1 > 200

    plt.figure(figsize=(8, 5))
    plt.plot(t_g1[~mask], k_g1[~mask], 'o', color='orange', label='Excluded data')
    plt.plot(t_sel, k_sel, 'o', color='darkblue', label='Selected data')
    plt.plot(t_sel, fit_200, 'r-', label='Linear fit (t > 200 s)')

    plt.xlabel('Time (s)')
    plt.ylabel('Conductivity (S/m)')
    plt.title('Evolution of conductivity with time')
    plt.grid(True, linestyle='--', alpha=0.6)
    plt.legend()

    plt.text(
        0.60, 0.20,
        f'y = {a_200:.2e}x + {b_200:.2e}\n$R^2$ = {r2_200:.4f}',
        transform=plt.gca().transAxes,
        bbox=dict(facecolor='white', alpha=0.7)
    )

    plt.tight_layout()
    plt.show()

    print("===Evolution of conductivity with time ===")
    print(f"Slope = {a_200:.6e} S/m/s")
    print(f"Intercept = {b_200:.6e}")
    print(f"R² = {r2_200:.4f}\n")
else:
    print("Group 1: not enough points after 200 s for regression.\n")

# =========================
# 6) GRAPHE 3 : COMPARAISON DES 4 GROUPES AVEC RÉGRESSIONS (t > 200 s)
# =========================
plt.figure(figsize=(10, 6))
markers = ['o', 's', '^', 'D']

for i, (name, (t, k)) in enumerate(groups.items()):
    plt.plot(t, k, markers[i], markersize=4, label=f"{name} data")

    result = linear_fit_after_200s(t, k)

    if result is None:
        print(f"{name}: not enough points after 200 s for linear regression.\n")
        continue

    t_sel, k_sel, a, b, fit, r2 = result

    plt.plot(t_sel, fit, '-', linewidth=2,
             label=f"{name} fit: y = {a:.2e}x + {b:.2e}")

    print(f"{name} regression after 200 s:")
    print(f"  slope = {a:.6e} S/m/s")
    print(f"  intercept = {b:.6e}")
    print(f"  R² = {r2:.4f}\n")

plt.xlabel("Time (s)")
plt.ylabel("Conductivity (S/m)")
plt.title("Comparison of the 4 groups with linear regression")
plt.grid(True, linestyle='--', alpha=0.6)
plt.legend(fontsize=8)
plt.tight_layout()
plt.show()

# =========================
# DIFFUSIVITY VS CONCENTRATION
# =========================

# Données
concentration = np.array([0.239, 0.290, 0.342, 0.250])  # mol/L
diffusivity = np.array([4.5e-4, 6.6e-4, 2.2e-4, 6.4e-4])  # cm^2/s

labels = ["G1", "G2", "G3", "G4"]

# Trier les données (OBLIGATOIRE)
sorted_indices = np.argsort(concentration)
concentration = concentration[sorted_indices]
diffusivity = diffusivity[sorted_indices]
labels = [labels[i] for i in sorted_indices]

# Interpolation spline (courbe lisse passant par tous les points)
x_smooth = np.linspace(concentration.min(), concentration.max(), 100)
spline = make_interp_spline(concentration, diffusivity, k=3)
y_smooth = spline(x_smooth)

# Plot
plt.figure(figsize=(8, 5))

# Points expérimentaux
plt.plot(concentration, diffusivity, 'o', label='Experimental data')

# Courbe pointillée lisse
plt.plot(x_smooth, y_smooth, '--', linewidth=2, label='Interpolated curve')

# Labels
for i in range(len(concentration)):
    plt.text(concentration[i] + 0.002, diffusivity[i], labels[i], fontsize=10)

plt.xlabel("Concentration (mol/L)")
plt.ylabel(r"Diffusivity $D_{AB}$ (cm$^2$/s)")
plt.title("Diffusivity as a function of concentration")
plt.grid(True, linestyle='--', alpha=0.6)
plt.legend()
plt.tight_layout()
plt.show()
